Content
Parsers: [custom_log]
Fields: [Month]

Reference
Fields: [class, env, linenum, mbody, msg, sevlvl, thread, timeday, timehour24, timeminute, timemsecond, timesecond, timeyearlong]
